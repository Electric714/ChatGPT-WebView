//
//  ChatGPTWebViewTests.swift
//  ChatGPTWebViewTests
//
//  Created by Mohamed Ali on 5/14/25.
//

import Testing

struct ChatGPTWebViewTests {

    @Test func example() async throws {
        // Write your test here and use APIs like `#expect(...)` to check expected conditions.
    }

}
